
package net.mcreator.stormlightmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SilverfishModel;

import net.mcreator.stormlightmod.entity.CultivationSprenEntity;

public class CultivationSprenRenderer extends MobRenderer<CultivationSprenEntity, SilverfishModel<CultivationSprenEntity>> {
	public CultivationSprenRenderer(EntityRendererProvider.Context context) {
		super(context, new SilverfishModel(context.bakeLayer(ModelLayers.SILVERFISH)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(CultivationSprenEntity entity) {
		return new ResourceLocation("stormlight_mod:textures/entities/cultivationspren_withface.png");
	}
}
